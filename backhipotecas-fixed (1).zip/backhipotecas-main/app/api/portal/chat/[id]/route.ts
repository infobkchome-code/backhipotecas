import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

// ⚙️ Cliente Supabase con SERVICE ROLE (solo servidor)
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Faltan variables de entorno de Supabase en la API de chat');
}

const supabaseAdmin = createClient(supabaseUrl!, supabaseServiceKey!);

type Remitente = 'cliente' | 'gestor';

type ChatMessage = {
  id: string;
  caso_id: string;
  remitente: Remitente;
  mensaje: string | null;
  attachment_name: string | null;
  attachment_path?: string | null;
  storage_path?: string | null;
  created_at: string;
};

type ApiListResponse = {
  ok: boolean;
  messages?: ChatMessage[];
  error?: string;
};

type ApiPostResponse = {
  ok: boolean;
  message?: ChatMessage;
  error?: string;
};

/**
 * GET → obtener todos los mensajes del chat de un caso
 * Además, marca cliente_tiene_mensajes_nuevos = FALSE en la tabla casos
 */
export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const casoId = params.id;

  if (!casoId) {
    return NextResponse.json(
      { ok: false, error: 'Falta el id del caso en la URL' },
      { status: 400 }
    );
  }

  // 1) Obtener mensajes
  const { data, error } = await supabaseAdmin
    .from('expediente_mensajes')
    .select(
      `
      id,
      caso_id,
      remitente,
      mensaje,
      attachment_name,
      attachment_path,
      storage_path,
      created_at
    `
    )
    .eq('caso_id', casoId)
    .order('created_at', { ascending: true });

  if (error) {
    console.error('Error GET chat:', error);
    return NextResponse.json(
      { ok: false, error: 'No se pudieron cargar los mensajes' },
      { status: 500 }
    );
  }

  // 2) Marcar como leídos los mensajes del cliente para este caso
  const { error: updError } = await supabaseAdmin
    .from('casos')
    .update({ cliente_tiene_mensajes_nuevos: false })
    .eq('id', casoId);

  if (updError) {
    console.error(
      'No se pudo actualizar cliente_tiene_mensajes_nuevos en casos:',
      updError
    );
  }

  return NextResponse.json({ ok: true, messages: data ?? [] } as ApiListResponse);
}

/**
 * POST → enviar mensaje al chat
 * - Admite JSON o FormData
 * - Permite mensaje, adjunto o ambos
 * - Si escribe el cliente → marca cliente_tiene_mensajes_nuevos = TRUE
 */
export async function POST(
  req: Request,
  { params }: { params: { id: string } }
) {
  const casoId = params.id;

  // 1) Intentar leer JSON; si falla, probar con FormData
  let body: any = {};
  try {
    body = await req.json();
  } catch {
    try {
      const form = await req.formData();
      body = Object.fromEntries(form.entries());
    } catch (e) {
      console.error('Error leyendo body en POST /chat:', e);
      return NextResponse.json(
        { ok: false, error: 'Cuerpo de la petición inválido' } as ApiPostResponse,
        { status: 400 }
      );
    }
  }

  const {
    remitente,
    mensaje,
    attachment_name,
    attachment_path,
    storage_path,
  } = body as {
    remitente?: Remitente;
    mensaje?: string;
    attachment_name?: string | null;
    attachment_path?: string | null;
    storage_path?: string | null;
  };

  if (!remitente || !['cliente', 'gestor'].includes(remitente)) {
    return NextResponse.json(
      { ok: false, error: 'Remitente no válido' } as ApiPostResponse,
      { status: 400 }
    );
  }

  const trimmedMensaje = mensaje?.toString().trim() ?? '';
  const hasMensaje = trimmedMensaje.length > 0;
  const hasAdjunto =
    !!attachment_name || !!attachment_path || !!storage_path;

  // ⛔ Solo error si NO hay ni mensaje ni adjunto
  if (!hasMensaje && !hasAdjunto) {
    return NextResponse.json(
      {
        ok: false,
        error: 'Debes enviar un mensaje o adjuntar un archivo',
      } as ApiPostResponse,
      { status: 400 }
    );
  }

  // 2) Insertar mensaje (incluyendo posibles adjuntos)
  const { data, error } = await supabaseAdmin
    .from('expediente_mensajes')
    .insert({
      caso_id: casoId,
      remitente,
      mensaje: hasMensaje ? trimmedMensaje : null,
      attachment_name: attachment_name ?? null,
      attachment_path: attachment_path ?? null,
      storage_path: storage_path ?? null,
    })
    .select(
      `
      id,
      caso_id,
      remitente,
      mensaje,
      attachment_name,
      attachment_path,
      storage_path,
      created_at
    `
    )
    .single();

  if (error) {
    console.error('Error POST chat:', error);
    return NextResponse.json(
      { ok: false, error: 'No se pudo guardar el mensaje' } as ApiPostResponse,
      { status: 500 }
    );
  }

  // 3) Si el remitente es el cliente, marcar que hay mensajes/documentos nuevos
  if (remitente === 'cliente') {
    const { error: updError } = await supabaseAdmin
      .from('casos')
      .update({ cliente_tiene_mensajes_nuevos: true })
      .eq('id', casoId);

    if (updError) {
      console.error(
        'No se pudo marcar cliente_tiene_mensajes_nuevos = true:',
        updError
      );
    }
  }

  return NextResponse.json({ ok: true, message: data } as ApiPostResponse);
}
